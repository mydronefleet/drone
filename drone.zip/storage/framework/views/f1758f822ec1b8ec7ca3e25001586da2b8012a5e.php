<?php $__env->startSection('content'); ?>
<div class="signin4">
        <div class="grid grid-cols-12">
            <div class="col-span-12 h-screen justify-center items-center hidden lg:flex lg:col-span-7" style="background-image:linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url(http://localhost/drone/public/images/signin-left.png);background-size: 100%;">
                <div class="px-10">
                    <p class="text-4xl text-white font-bold mb-3">Don't have an account?</p>
                    <p class="text-base text-white font-semibold mb-5">Stop wasting time and money. It's free!</p>
                    <a class="btn bg-yellow-600" href="<?php echo e(url('/register')); ?>">Sign Up</a>
                </div>
            </div>
            <div class="col-span-12 h-screen lg:col-span-5">
                <div class="h-full overflow-scroll">
                    <div class="flex justify-center">
                        <div class="my-10 text-center"><img class="h-24 m-auto" src="<?php echo e(asset('public/images/DroneFleetRPIC96x96.png')); ?>">
                            <p class="text-lg text-primary-500 font-black">My Fly Login</p>
                            <p class="text-base text-gray-400 font-bold">Sign in to your account </p>
                        </div>
                    </div>
                    <div class="px-10 pt-10">
						<form method="POST" action="<?php echo e(route('login')); ?>">
							<?php echo csrf_field(); ?>
							<input class="ul-form-input mb-4 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" type="text" value="<?php echo e(old('email')); ?>" placeholder="Username" required autocomplete="email" autofocus>
							
							<input class="ul-form-input mb-8 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password"  name="password" required autocomplete="current-password">
							<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<span class="invalid-feedback" role="alert">
									<strong><?php echo e($message); ?></strong>
								</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							<label class="inline-flex items-center mt-3 mb-4">
								<input class="form-checkbox h-5 w-5 border border-gray-900 text-primary-500 rounded" type="checkbox" checked=""><span class="ml-2 text-gray-700 font-bold">I Agree with Terms And Conditions</span>
							</label>
							<button class="btn mb-2 btn btn-block btn-primary mb-3" type="submit">Signin</button>
							<div class="block lg:hidden">
								<button class="btn mb-2 btn btn-block btn-primary" type="button">Sign Up</button>
							</div>
							<div class="mb-8"></div>
							<div class="border-b border-gray-300 mb-5"></div>
							<div class="text-center">
								<p class="text-base font-black mb-8">Sign In WIth</p>
							</div>
							<div class="flex justify-center text-center mb-8">
								<button class="btn mr-2 btn btn-danger-outline" type="button">Google</button>
								<button class="btn mr-2 btn btn-info-outline" type="button">Facebook</button>
								<button class="btn mr-2 btn btn-primary-outline" type="button">Twitter</button>
							</div>
						</form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\drone\resources\views/auth/login.blade.php ENDPATH**/ ?>