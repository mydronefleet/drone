<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    
    <link href="https://fonts.googleapis.com/css?family=Material+Icons" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" />
    <link rel="stylesheet" href="{{ asset('public/css/vendors.bundle.min.css') }}" />
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="{{ asset('public/css/main.bundle.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/css/tailwind.bundle.min.css') }}" />
	<link href="{{ asset('public/css/app.css') }}" rel="stylesheet">
</head>
<body>
    <div id="app">
        @yield('content')
        
    </div>
	
		<script src="{{ asset('public/js/vendors.bundle.min.js') }}"></script>
	<script src="{{ asset('public/js/main.bundle.min.js') }}"></script>
	<script src="{{ asset('public/js/pages/dropdown.min.js') }}"></script>
	<script src="{{ asset('public/js/pages/modal.min.js') }}"></script>
	<script src="{{ asset('public/js/pages/dashboard/dataSeries.script.js') }}"></script>
	<script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" type="text/javascript"></script>
    <script src="{{ asset('public/js/pages/dashboard/dashboard.v1.script.js') }}"></script>
</body>
</html>
